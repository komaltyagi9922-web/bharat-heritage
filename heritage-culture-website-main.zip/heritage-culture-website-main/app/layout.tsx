import React from "react"
import type { Metadata, Viewport } from 'next'
import { Playfair_Display, Crimson_Text } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const playfair = Playfair_Display({ 
  subsets: ["latin"],
  variable: '--font-playfair',
  display: 'swap',
})

const crimson = Crimson_Text({ 
  subsets: ["latin"],
  weight: ['400', '600', '700'],
  variable: '--font-crimson',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Bharat Heritage | Discover India\'s Timeless Monuments',
  description: 'Explore India\'s rich cultural heritage through our comprehensive guide to famous monuments, temples, palaces, and forts. Plan your heritage trip with AI-powered recommendations.',
  keywords: ['Indian monuments', 'heritage sites', 'Taj Mahal', 'temples', 'cultural tourism', 'India travel'],
  openGraph: {
    title: 'Bharat Heritage | Discover India\'s Timeless Monuments',
    description: 'Explore India\'s rich cultural heritage through famous monuments and temples.',
    type: 'website',
  },
    generator: 'v0.app'
}

export const viewport: Viewport = {
  themeColor: '#B45309',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${playfair.variable} ${crimson.variable} font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
