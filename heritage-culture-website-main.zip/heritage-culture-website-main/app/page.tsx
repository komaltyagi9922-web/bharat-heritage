'use client'

import { useState, useRef } from 'react'
import { Header } from '@/components/header'
import { HeroSection } from '@/components/hero-section'
import { MonumentsGallery } from '@/components/monuments-gallery'
import { HeritageMap } from '@/components/heritage-map'
import { TripPlanner } from '@/components/trip-planner'
import { HeritageChatbot } from '@/components/heritage-chatbot'
import { Footer } from '@/components/footer'

export default function HeritagePage() {
  const [selectedMonumentId, setSelectedMonumentId] = useState<string | null>(null)
  const monumentsRef = useRef<HTMLDivElement>(null)

  const scrollToMonuments = () => {
    monumentsRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const handleSelectMonument = (id: string | null) => {
    setSelectedMonumentId(id)
    if (id) {
      // Scroll to monuments section if not already there
      const monumentsSection = document.getElementById('monuments')
      if (monumentsSection) {
        const rect = monumentsSection.getBoundingClientRect()
        if (rect.top > window.innerHeight || rect.bottom < 0) {
          monumentsSection.scrollIntoView({ behavior: 'smooth' })
        }
      }
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        <HeroSection 
          onViewMonuments={scrollToMonuments}
          onSelectMonument={handleSelectMonument}
        />
        
        <div ref={monumentsRef}>
          <MonumentsGallery 
            selectedMonumentId={selectedMonumentId}
            onSelectMonument={handleSelectMonument}
          />
        </div>
        
        <HeritageMap onSelectMonument={handleSelectMonument} />
        
        <TripPlanner onSelectMonument={handleSelectMonument} />
      </main>

      <Footer />
      
      {/* Floating Chatbot */}
      <div id="chatbot">
        <HeritageChatbot />
      </div>
    </div>
  )
}
