import {
  consumeStream,
  convertToModelMessages,
  streamText,
  UIMessage,
} from 'ai'
import { monuments } from '@/lib/monuments-data'

export const maxDuration = 30

// Create a context string with all monument information
function getMonumentsContext(): string {
  return monuments.map(m => `
Monument: ${m.name}
Location: ${m.location}, ${m.state}
Category: ${m.category}
Description: ${m.fullDescription}
History: ${m.history}
Visiting Hours: ${m.visitingHours}
Entry Fee (Indian): ${m.ticketFees.indian}
Entry Fee (Foreign): ${m.ticketFees.foreign}
Best Time to Visit: ${m.bestTimeToVisit}
Facilities: ${m.facilities.join(', ')}
Built: ${m.yearBuilt} by ${m.builtBy}
Architecture Style: ${m.architecturalStyle}
UNESCO Site: ${m.unescoSite ? 'Yes' : 'No'}
  `).join('\n---\n')
}

const systemPrompt = `You are an expert AI Heritage Guide for Indian monuments and temples. You have comprehensive knowledge about India's cultural heritage sites.

Your responsibilities:
1. Answer questions about specific monuments, including their history, visiting hours, ticket fees, locations, and facilities
2. Provide travel recommendations based on the user's interests and time of year
3. Help users plan their heritage trips
4. Share interesting historical facts and architectural details
5. Suggest the best time to visit based on weather and festivals

Here is your knowledge base of monuments:
${getMonumentsContext()}

Guidelines:
- Be friendly, informative, and enthusiastic about Indian heritage
- Provide accurate information from your knowledge base
- If asked about a monument not in your database, politely mention you specialize in the 10 major monuments listed
- When recommending monuments, consider the current season (winter: Oct-Feb is best for most sites)
- Include practical tips like visiting early morning to avoid crowds
- Use emojis sparingly to make responses engaging
- Keep responses concise but informative
- If user says "list all" or asks about all monuments, provide a brief list
- If user needs help, explain what kind of questions you can answer

Special Commands:
- "list all" - Show all available monuments
- "help" - Explain your capabilities`

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json()

  const result = streamText({
    model: 'openai/gpt-4o-mini',
    system: systemPrompt,
    messages: await convertToModelMessages(messages),
    abortSignal: req.signal,
    maxTokens: 1000,
  })

  return result.toUIMessageStreamResponse({
    originalMessages: messages,
    consumeSseStream: consumeStream,
  })
}
