import Link from 'next/link'
import { MapPin, Mail, Phone, Heart } from 'lucide-react'

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-foreground text-background">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">B</span>
              </div>
              <div>
                <span className="font-bold text-lg text-background">Bharat Heritage</span>
              </div>
            </div>
            <p className="text-background/70 mb-4 max-w-sm">
              Your comprehensive guide to exploring India&apos;s rich cultural heritage. 
              Discover monuments, temples, palaces, and forts with AI-powered assistance.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-background mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="#monuments" className="text-background/70 hover:text-background transition-colors">
                  Monuments
                </Link>
              </li>
              <li>
                <Link href="#map" className="text-background/70 hover:text-background transition-colors">
                  Heritage Map
                </Link>
              </li>
              <li>
                <Link href="#chatbot" className="text-background/70 hover:text-background transition-colors">
                  AI Guide
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-background mb-4">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-background/70">
                <MapPin className="w-4 h-4" />
                <span>New Delhi, India</span>
              </li>
              <li className="flex items-center gap-2 text-background/70">
                <Mail className="w-4 h-4" />
                <span>info@bharatheritage.com</span>
              </li>
              <li className="flex items-center gap-2 text-background/70">
                <Phone className="w-4 h-4" />
                <span>+91 123 456 7890</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-background/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-background/60 text-sm">
            {currentYear} Bharat Heritage. All rights reserved.
          </p>
          <p className="text-background/60 text-sm flex items-center gap-1">
            Made with <Heart className="w-4 h-4 text-primary fill-primary" /> for Indian Heritage
          </p>
        </div>
      </div>
    </footer>
  )
}
