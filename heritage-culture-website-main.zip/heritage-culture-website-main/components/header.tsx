'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Menu, X, MapPin, MessageCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-card/95 backdrop-blur-sm border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">B</span>
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-lg text-foreground leading-none">Bharat Heritage</span>
              <span className="text-xs text-muted-foreground">Discover India&apos;s Legacy</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-foreground hover:text-primary transition-colors font-medium">
              Home
            </Link>
            <Link href="#monuments" className="text-muted-foreground hover:text-primary transition-colors font-medium">
              Monuments
            </Link>
            <Link href="#map" className="text-muted-foreground hover:text-primary transition-colors font-medium flex items-center gap-1">
              <MapPin className="w-4 h-4" />
              Map
            </Link>
            <Link href="#chatbot" className="text-muted-foreground hover:text-primary transition-colors font-medium flex items-center gap-1">
              <MessageCircle className="w-4 h-4" />
              AI Guide
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden py-4 border-t border-border">
            <div className="flex flex-col gap-3">
              <Link 
                href="/" 
                className="text-foreground hover:text-primary transition-colors font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link 
                href="#monuments" 
                className="text-muted-foreground hover:text-primary transition-colors font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Monuments
              </Link>
              <Link 
                href="#map" 
                className="text-muted-foreground hover:text-primary transition-colors font-medium py-2 flex items-center gap-1"
                onClick={() => setIsMenuOpen(false)}
              >
                <MapPin className="w-4 h-4" />
                Map
              </Link>
              <Link 
                href="#chatbot" 
                className="text-muted-foreground hover:text-primary transition-colors font-medium py-2 flex items-center gap-1"
                onClick={() => setIsMenuOpen(false)}
              >
                <MessageCircle className="w-4 h-4" />
                AI Guide
              </Link>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}
