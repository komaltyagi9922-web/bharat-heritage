'use client'

import { useState } from 'react'
import Image from 'next/image'
import { MapPin, Navigation, ExternalLink } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { monuments, type Monument } from '@/lib/monuments-data'

interface HeritageMapProps {
  onSelectMonument: (id: string) => void
}

// India map regions with approximate positions (percentage-based)
const mapPositions: Record<string, { top: string; left: string }> = {
  'taj-mahal': { top: '38%', left: '52%' }, // Agra
  'red-fort': { top: '32%', left: '52%' }, // Delhi
  'golden-temple': { top: '25%', left: '46%' }, // Amritsar
  'hawa-mahal': { top: '38%', left: '44%' }, // Jaipur
  'qutub-minar': { top: '33%', left: '51%' }, // Delhi
  'mysore-palace': { top: '78%', left: '48%' }, // Mysore
  'konark-sun-temple': { top: '52%', left: '70%' }, // Konark
  'gateway-of-india': { top: '58%', left: '40%' }, // Mumbai
  'khajuraho': { top: '46%', left: '56%' }, // Khajuraho
  'meenakshi-temple': { top: '85%', left: '52%' }, // Madurai
}

export function HeritageMap({ onSelectMonument }: HeritageMapProps) {
  const [hoveredMonument, setHoveredMonument] = useState<Monument | null>(null)
  const [selectedPin, setSelectedPin] = useState<string | null>(null)

  const openInMaps = (monument: Monument) => {
    const url = `https://www.google.com/maps/search/?api=1&query=${monument.coordinates.lat},${monument.coordinates.lng}`
    window.open(url, '_blank')
  }

  return (
    <section id="map" className="py-16 md:py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12">
          <Badge variant="outline" className="mb-4 px-4 py-2">
            <Navigation className="w-4 h-4 mr-2" />
            Interactive Map
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Smart Heritage Map
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore the geographical spread of India&apos;s heritage sites. 
            Click on any pin to view details or get directions.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Map Container */}
          <div className="lg:col-span-2">
            <Card className="overflow-hidden">
              <CardContent className="p-0">
                <div className="relative bg-gradient-to-br from-primary/5 to-accent/5 min-h-[500px] md:min-h-[600px]">
                  {/* India Map Background (stylized) */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <svg 
                      viewBox="0 0 200 250" 
                      className="w-full h-full max-w-md opacity-20"
                      fill="none"
                    >
                      <path 
                        d="M100 10 L130 20 L150 40 L160 70 L170 100 L175 130 L170 160 L150 190 L130 210 L100 230 L70 220 L50 200 L35 170 L30 140 L35 110 L45 80 L60 50 L80 25 Z"
                        fill="currentColor"
                        className="text-primary"
                      />
                    </svg>
                  </div>

                  {/* Monument Pins */}
                  {monuments.map((monument) => {
                    const position = mapPositions[monument.id]
                    if (!position) return null

                    return (
                      <button
                        key={monument.id}
                        className={`absolute transform -translate-x-1/2 -translate-y-full transition-all duration-200 z-10 group ${
                          selectedPin === monument.id ? 'scale-125 z-20' : 'hover:scale-110'
                        }`}
                        style={{ top: position.top, left: position.left }}
                        onClick={() => {
                          setSelectedPin(selectedPin === monument.id ? null : monument.id)
                          setHoveredMonument(monument)
                        }}
                        onMouseEnter={() => setHoveredMonument(monument)}
                        onMouseLeave={() => {
                          if (selectedPin !== monument.id) {
                            setHoveredMonument(null)
                          }
                        }}
                      >
                        <div className={`relative ${selectedPin === monument.id ? 'animate-bounce' : ''}`}>
                          <MapPin 
                            className={`w-8 h-8 drop-shadow-lg transition-colors ${
                              selectedPin === monument.id 
                                ? 'text-accent fill-accent' 
                                : 'text-primary fill-primary hover:text-accent hover:fill-accent'
                            }`}
                          />
                          {monument.unescoSite && (
                            <div className="absolute -top-1 -right-1 w-3 h-3 bg-gold rounded-full border-2 border-card" />
                          )}
                        </div>
                        {/* Tooltip */}
                        <div className={`absolute bottom-full left-1/2 -translate-x-1/2 mb-2 whitespace-nowrap bg-card text-foreground text-xs font-medium px-2 py-1 rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none ${
                          selectedPin === monument.id ? 'opacity-100' : ''
                        }`}>
                          {monument.name}
                        </div>
                      </button>
                    )
                  })}

                  {/* Legend */}
                  <div className="absolute bottom-4 left-4 bg-card/90 backdrop-blur-sm rounded-lg p-3 text-xs">
                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="w-4 h-4 text-primary fill-primary" />
                      <span className="text-foreground">Heritage Site</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-gold rounded-full" />
                      <span className="text-foreground">UNESCO Site</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Monument Info Panel */}
          <div>
            <Card className="sticky top-24 h-fit">
              <CardContent className="p-6">
                {hoveredMonument ? (
                  <div>
                    <div className="relative h-40 rounded-lg overflow-hidden mb-4">
                      <Image
                        src={hoveredMonument.image || "/placeholder.svg"}
                        alt={hoveredMonument.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <Badge className="mb-2">{hoveredMonument.category}</Badge>
                    <h3 className="text-xl font-bold text-foreground mb-2">
                      {hoveredMonument.name}
                    </h3>
                    <p className="text-muted-foreground text-sm mb-4 flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {hoveredMonument.location}, {hoveredMonument.state}
                    </p>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                      {hoveredMonument.shortDescription}
                    </p>
                    <div className="flex gap-2">
                      <Button 
                        className="flex-1"
                        onClick={() => onSelectMonument(hoveredMonument.id)}
                      >
                        View Details
                      </Button>
                      <Button 
                        variant="outline" 
                        size="icon"
                        onClick={() => openInMaps(hoveredMonument)}
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <MapPin className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-lg font-semibold text-foreground mb-2">
                      Select a Location
                    </h3>
                    <p className="text-muted-foreground text-sm">
                      Click on any pin on the map to view monument details
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
