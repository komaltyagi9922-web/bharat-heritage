'use client'

import { useState, useMemo } from 'react'
import { Search, Filter, SlidersHorizontal } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { MonumentCard } from './monument-card'
import { MonumentDetails } from './monument-details'
import { monuments, type Monument } from '@/lib/monuments-data'

const categories = ['All', 'Monument', 'Temple', 'Palace', 'Fort'] as const
type CategoryFilter = typeof categories[number]

interface MonumentsGalleryProps {
  selectedMonumentId?: string | null
  onSelectMonument: (id: string | null) => void
}

export function MonumentsGallery({ selectedMonumentId, onSelectMonument }: MonumentsGalleryProps) {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<CategoryFilter>('All')

  const filteredMonuments = useMemo(() => {
    return monuments.filter((monument) => {
      const matchesSearch = 
        monument.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        monument.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        monument.state.toLowerCase().includes(searchQuery.toLowerCase())
      
      const matchesCategory = 
        selectedCategory === 'All' || monument.category === selectedCategory

      return matchesSearch && matchesCategory
    })
  }, [searchQuery, selectedCategory])

  const selectedMonument = selectedMonumentId 
    ? monuments.find(m => m.id === selectedMonumentId) 
    : null

  return (
    <section id="monuments" className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12">
          <Badge variant="outline" className="mb-4 px-4 py-2">
            <SlidersHorizontal className="w-4 h-4 mr-2" />
            Browse Collection
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Famous Monuments & Temples
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore our curated collection of India&apos;s most iconic heritage sites. 
            Use filters to find monuments by category or search by name and location.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search monuments by name, location, or state..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 py-6 bg-card"
            />
          </div>

          {/* Category Filters */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0">
            <Filter className="w-5 h-5 text-muted-foreground flex-shrink-0" />
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className={selectedCategory === category 
                  ? 'bg-primary text-primary-foreground' 
                  : 'border-border hover:bg-muted'
                }
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Results Count */}
        <p className="text-muted-foreground mb-6">
          Showing <span className="font-semibold text-foreground">{filteredMonuments.length}</span> monuments
        </p>

        {/* Monument Grid */}
        {filteredMonuments.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMonuments.map((monument) => (
              <MonumentCard
                key={monument.id}
                monument={monument}
                onClick={() => onSelectMonument(monument.id)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-muted/30 rounded-2xl">
            <p className="text-muted-foreground text-lg mb-2">No monuments found</p>
            <p className="text-sm text-muted-foreground">
              Try adjusting your search or filter criteria
            </p>
            <Button 
              variant="outline" 
              className="mt-4 bg-transparent"
              onClick={() => {
                setSearchQuery('')
                setSelectedCategory('All')
              }}
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>

      {/* Monument Details Modal */}
      {selectedMonument && (
        <MonumentDetails
          monument={selectedMonument}
          onClose={() => onSelectMonument(null)}
        />
      )}
    </section>
  )
}
