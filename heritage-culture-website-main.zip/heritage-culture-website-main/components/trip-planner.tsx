'use client'

import { useState } from 'react'
import Image from 'next/image'
import { 
  Calendar, MapPin, Clock, Sparkles, 
  ChevronRight, Check, Route
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { monuments, type Monument } from '@/lib/monuments-data'

interface TripPlannerProps {
  onSelectMonument: (id: string) => void
}

interface TripItinerary {
  day: number
  monuments: Monument[]
  region: string
}

const regions = [
  { id: 'north', name: 'North India', states: ['Delhi', 'Uttar Pradesh', 'Rajasthan', 'Punjab'] },
  { id: 'south', name: 'South India', states: ['Karnataka', 'Tamil Nadu'] },
  { id: 'east', name: 'East India', states: ['Odisha'] },
  { id: 'west', name: 'West India', states: ['Maharashtra'] },
]

const durations = [
  { value: '3', label: '3 Days' },
  { value: '5', label: '5 Days' },
  { value: '7', label: '7 Days (Recommended)' },
  { value: '10', label: '10 Days' },
]

export function TripPlanner({ onSelectMonument }: TripPlannerProps) {
  const [selectedRegion, setSelectedRegion] = useState<string>('')
  const [selectedDuration, setSelectedDuration] = useState<string>('')
  const [itinerary, setItinerary] = useState<TripItinerary[] | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)

  const generateItinerary = () => {
    if (!selectedRegion || !selectedDuration) return

    setIsGenerating(true)

    // Simulate AI processing
    setTimeout(() => {
      const region = regions.find(r => r.id === selectedRegion)
      if (!region) return

      const regionMonuments = monuments.filter(m => region.states.includes(m.state))
      const days = parseInt(selectedDuration)
      const monumentsPerDay = Math.ceil(regionMonuments.length / days)
      
      const plan: TripItinerary[] = []
      let monumentIndex = 0

      for (let day = 1; day <= days && monumentIndex < regionMonuments.length; day++) {
        const dayMonuments = regionMonuments.slice(monumentIndex, monumentIndex + monumentsPerDay)
        if (dayMonuments.length > 0) {
          plan.push({
            day,
            monuments: dayMonuments,
            region: region.name
          })
        }
        monumentIndex += monumentsPerDay
      }

      // If we have extra days, add travel/exploration days
      if (plan.length < days) {
        for (let i = plan.length + 1; i <= days; i++) {
          plan.push({
            day: i,
            monuments: [],
            region: `Explore ${region.name} - Local Markets & Cuisine`
          })
        }
      }

      setItinerary(plan)
      setIsGenerating(false)
    }, 1500)
  }

  const resetPlanner = () => {
    setSelectedRegion('')
    setSelectedDuration('')
    setItinerary(null)
  }

  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12">
          <Badge variant="outline" className="mb-4 px-4 py-2">
            <Route className="w-4 h-4 mr-2" />
            AI Trip Planner
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Plan Your Heritage Journey
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Let our AI create a personalized itinerary based on your preferences. 
            Select your region and duration to get started.
          </p>
        </div>

        {!itinerary ? (
          // Planner Form
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                Create Your Itinerary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Region Selection */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Select Region
                </label>
                <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Choose a region to explore" />
                  </SelectTrigger>
                  <SelectContent>
                    {regions.map((region) => (
                      <SelectItem key={region.id} value={region.id}>
                        <span className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          {region.name}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {selectedRegion && (
                  <p className="mt-2 text-sm text-muted-foreground">
                    Covers: {regions.find(r => r.id === selectedRegion)?.states.join(', ')}
                  </p>
                )}
              </div>

              {/* Duration Selection */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Trip Duration
                </label>
                <Select value={selectedDuration} onValueChange={setSelectedDuration}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="How many days?" />
                  </SelectTrigger>
                  <SelectContent>
                    {durations.map((duration) => (
                      <SelectItem key={duration.value} value={duration.value}>
                        <span className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          {duration.label}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Generate Button */}
              <Button 
                className="w-full py-6 text-lg"
                onClick={generateItinerary}
                disabled={!selectedRegion || !selectedDuration || isGenerating}
              >
                {isGenerating ? (
                  <>
                    <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                    Generating Your Trip...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 mr-2" />
                    Generate Itinerary
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        ) : (
          // Generated Itinerary
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-2xl font-bold text-foreground">
                  Your {selectedDuration}-Day {regions.find(r => r.id === selectedRegion)?.name} Adventure
                </h3>
                <p className="text-muted-foreground">
                  AI-curated itinerary for an unforgettable heritage experience
                </p>
              </div>
              <Button variant="outline" onClick={resetPlanner}>
                Plan Another Trip
              </Button>
            </div>

            {/* Timeline */}
            <div className="space-y-6">
              {itinerary.map((day, index) => (
                <Card key={day.day} className="relative overflow-hidden">
                  {/* Timeline connector */}
                  {index < itinerary.length - 1 && (
                    <div className="absolute left-8 top-full w-0.5 h-6 bg-border z-10" />
                  )}
                  
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      {/* Day Badge */}
                      <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                        <span className="text-primary-foreground font-bold">D{day.day}</span>
                      </div>

                      <div className="flex-1">
                        {day.monuments.length > 0 ? (
                          <>
                            <h4 className="font-semibold text-foreground mb-4">
                              Day {day.day} - Explore Heritage Sites
                            </h4>
                            <div className="grid sm:grid-cols-2 gap-4">
                              {day.monuments.map((monument) => (
                                <button
                                  key={monument.id}
                                  onClick={() => onSelectMonument(monument.id)}
                                  className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors text-left group"
                                >
                                  <div className="relative w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                                    <Image
                                      src={monument.image || "/placeholder.svg"}
                                      alt={monument.name}
                                      fill
                                      className="object-cover"
                                    />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <p className="font-medium text-foreground truncate group-hover:text-primary transition-colors">
                                      {monument.name}
                                    </p>
                                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                                      <MapPin className="w-3 h-3" />
                                      {monument.location}
                                    </p>
                                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                                      <Clock className="w-3 h-3" />
                                      {monument.visitingHours.split('(')[0].trim()}
                                    </p>
                                  </div>
                                  <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
                                </button>
                              ))}
                            </div>
                          </>
                        ) : (
                          <>
                            <h4 className="font-semibold text-foreground mb-2">
                              Day {day.day} - {day.region}
                            </h4>
                            <p className="text-muted-foreground">
                              Take time to explore local culture, markets, and cuisine. 
                              This is a great day for photography and soaking in the atmosphere.
                            </p>
                          </>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Tips Section */}
            <Card className="mt-8 bg-primary/5 border-primary/20">
              <CardContent className="p-6">
                <h4 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary" />
                  Travel Tips
                </h4>
                <ul className="space-y-2">
                  {[
                    'Start early in the morning (before 8 AM) to avoid crowds and heat',
                    'Carry water, sunscreen, and comfortable walking shoes',
                    'Book skip-the-line tickets online when available',
                    'Hire local guides for deeper historical insights',
                    'Respect local customs and dress codes at religious sites'
                  ].map((tip) => (
                    <li key={tip} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <Check className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
                      {tip}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </section>
  )
}
