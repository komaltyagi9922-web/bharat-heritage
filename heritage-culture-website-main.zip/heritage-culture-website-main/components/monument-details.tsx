'use client'

import Image from 'next/image'
import { 
  X, MapPin, Clock, Ticket, Calendar, Building2, 
  Award, CheckCircle, History, ArrowLeft 
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import type { Monument } from '@/lib/monuments-data'

interface MonumentDetailsProps {
  monument: Monument
  onClose: () => void
}

export function MonumentDetails({ monument, onClose }: MonumentDetailsProps) {
  return (
    <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm overflow-y-auto">
      <div className="min-h-screen py-8 px-4">
        <div className="max-w-4xl mx-auto bg-card rounded-2xl shadow-2xl border border-border overflow-hidden">
          {/* Header Image */}
          <div className="relative h-64 md:h-96">
            <Image
              src={monument.image || "/placeholder.svg"}
              alt={monument.name}
              fill
              className="object-cover"
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/90 via-foreground/30 to-transparent" />
            
            {/* Close Button */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4 bg-card/80 hover:bg-card text-foreground"
              onClick={onClose}
            >
              <X className="w-5 h-5" />
            </Button>

            {/* Back Button */}
            <Button
              variant="ghost"
              size="sm"
              className="absolute top-4 left-4 bg-card/80 hover:bg-card text-foreground"
              onClick={onClose}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>

            {/* Title Section */}
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <div className="flex flex-wrap gap-2 mb-3">
                <Badge className="bg-primary text-primary-foreground">
                  {monument.category}
                </Badge>
                {monument.unescoSite && (
                  <Badge className="bg-accent text-accent-foreground flex items-center gap-1">
                    <Award className="w-3 h-3" />
                    UNESCO World Heritage Site
                  </Badge>
                )}
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
                {monument.name}
              </h1>
              <div className="flex items-center gap-2 text-white/90">
                <MapPin className="w-5 h-5" />
                <span>{monument.location}, {monument.state}</span>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-6 md:p-8">
            {/* Quick Info Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="bg-secondary/50 rounded-xl p-4 text-center">
                <Clock className="w-6 h-6 mx-auto mb-2 text-primary" />
                <p className="text-xs text-muted-foreground mb-1">Visiting Hours</p>
                <p className="text-sm font-medium text-foreground">{monument.visitingHours.split('(')[0].trim()}</p>
              </div>
              <div className="bg-secondary/50 rounded-xl p-4 text-center">
                <Ticket className="w-6 h-6 mx-auto mb-2 text-primary" />
                <p className="text-xs text-muted-foreground mb-1">Entry Fee (Indian)</p>
                <p className="text-sm font-medium text-foreground">{monument.ticketFees.indian}</p>
              </div>
              <div className="bg-secondary/50 rounded-xl p-4 text-center">
                <Calendar className="w-6 h-6 mx-auto mb-2 text-primary" />
                <p className="text-xs text-muted-foreground mb-1">Best Time</p>
                <p className="text-sm font-medium text-foreground">{monument.bestTimeToVisit.split('(')[0].trim()}</p>
              </div>
              <div className="bg-secondary/50 rounded-xl p-4 text-center">
                <Building2 className="w-6 h-6 mx-auto mb-2 text-primary" />
                <p className="text-xs text-muted-foreground mb-1">Architecture</p>
                <p className="text-sm font-medium text-foreground">{monument.architecturalStyle.replace(' Architecture', '')}</p>
              </div>
            </div>

            {/* Description */}
            <section className="mb-8">
              <h2 className="text-xl font-bold text-foreground mb-4">About</h2>
              <p className="text-muted-foreground leading-relaxed">
                {monument.fullDescription}
              </p>
            </section>

            <Separator className="my-8" />

            {/* History */}
            <section className="mb-8">
              <h2 className="text-xl font-bold text-foreground mb-4 flex items-center gap-2">
                <History className="w-5 h-5 text-primary" />
                History
              </h2>
              <p className="text-muted-foreground leading-relaxed">
                {monument.history}
              </p>
              <div className="mt-4 flex flex-wrap gap-4 text-sm">
                <div className="bg-muted px-4 py-2 rounded-lg">
                  <span className="text-muted-foreground">Built: </span>
                  <span className="font-medium text-foreground">{monument.yearBuilt}</span>
                </div>
                <div className="bg-muted px-4 py-2 rounded-lg">
                  <span className="text-muted-foreground">By: </span>
                  <span className="font-medium text-foreground">{monument.builtBy}</span>
                </div>
              </div>
            </section>

            <Separator className="my-8" />

            {/* Ticket Information */}
            <section className="mb-8">
              <h2 className="text-xl font-bold text-foreground mb-4 flex items-center gap-2">
                <Ticket className="w-5 h-5 text-primary" />
                Ticket Information
              </h2>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
                  <p className="text-sm text-muted-foreground mb-1">Indian Citizens</p>
                  <p className="text-2xl font-bold text-primary">{monument.ticketFees.indian}</p>
                </div>
                <div className="bg-accent/5 border border-accent/20 rounded-xl p-4">
                  <p className="text-sm text-muted-foreground mb-1">Foreign Nationals</p>
                  <p className="text-2xl font-bold text-accent">{monument.ticketFees.foreign}</p>
                </div>
              </div>
            </section>

            <Separator className="my-8" />

            {/* Facilities */}
            <section>
              <h2 className="text-xl font-bold text-foreground mb-4">Available Facilities</h2>
              <div className="flex flex-wrap gap-3">
                {monument.facilities.map((facility) => (
                  <Badge 
                    key={facility} 
                    variant="outline" 
                    className="px-4 py-2 flex items-center gap-2 bg-muted/50"
                  >
                    <CheckCircle className="w-4 h-4 text-accent" />
                    {facility}
                  </Badge>
                ))}
              </div>
            </section>

            {/* Visit Tip */}
            <div className="mt-8 bg-primary/5 border border-primary/20 rounded-xl p-6">
              <h3 className="font-bold text-foreground mb-2">Pro Tip</h3>
              <p className="text-muted-foreground">
                {monument.bestTimeToVisit}. Visit early in the morning or late afternoon 
                for the best photography opportunities and to avoid crowds.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
