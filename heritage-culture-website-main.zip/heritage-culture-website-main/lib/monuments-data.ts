export interface Monument {
  id: string
  name: string
  location: string
  state: string
  category: 'Monument' | 'Temple' | 'Palace' | 'Fort'
  image: string
  shortDescription: string
  fullDescription: string
  history: string
  visitingHours: string
  ticketFees: {
    indian: string
    foreign: string
  }
  bestTimeToVisit: string
  facilities: string[]
  coordinates: {
    lat: number
    lng: number
  }
  yearBuilt: string
  builtBy: string
  architecturalStyle: string
  unescoSite: boolean
}

export const monuments: Monument[] = [
  {
    id: 'taj-mahal',
    name: 'Taj Mahal',
    location: 'Agra',
    state: 'Uttar Pradesh',
    category: 'Monument',
    image: '/monuments/taj-mahal.jpg',
    shortDescription: 'An ivory-white marble mausoleum, one of the Seven Wonders of the World.',
    fullDescription: 'The Taj Mahal is an ivory-white marble mausoleum on the right bank of the river Yamuna in Agra, India. It was commissioned in 1632 by the Mughal emperor Shah Jahan to house the tomb of his favorite wife, Mumtaz Mahal.',
    history: 'The construction of the Taj Mahal began in 1632 and was completed in 1653. It is said that over 20,000 artisans worked on this magnificent structure. The chief architect was Ustad Ahmad Lahori. The Taj Mahal is considered the finest example of Mughal architecture, which combines Indian, Persian, and Islamic influences.',
    visitingHours: 'Sunrise to Sunset (Closed on Fridays)',
    ticketFees: {
      indian: '₹50',
      foreign: '₹1,100'
    },
    bestTimeToVisit: 'October to March (Winter season for pleasant weather)',
    facilities: ['Wheelchair Access', 'Audio Guide', 'Guided Tours', 'Restrooms', 'Parking', 'Photography Allowed'],
    coordinates: { lat: 27.1751, lng: 78.0421 },
    yearBuilt: '1632-1653',
    builtBy: 'Emperor Shah Jahan',
    architecturalStyle: 'Mughal Architecture',
    unescoSite: true
  },
  {
    id: 'red-fort',
    name: 'Red Fort',
    location: 'Delhi',
    state: 'Delhi',
    category: 'Fort',
    image: '/monuments/red-fort.jpg',
    shortDescription: 'A historic fort that served as the main residence of the Mughal Emperors.',
    fullDescription: 'The Red Fort, also known as Lal Qila, is a historic fort in Old Delhi that served as the main residence of the Mughal Emperors. The massive red sandstone walls, which stand 75 feet high, were designed to keep out invaders.',
    history: 'The Red Fort was built by Emperor Shah Jahan in 1639 when he decided to shift his capital from Agra to Delhi. The construction was completed in 1648. The fort is a masterpiece of Mughal architecture and has been the site of India\'s Independence Day celebrations since 1947.',
    visitingHours: '9:30 AM to 4:30 PM (Closed on Mondays)',
    ticketFees: {
      indian: '₹35',
      foreign: '₹500'
    },
    bestTimeToVisit: 'October to March',
    facilities: ['Sound & Light Show', 'Museum', 'Guided Tours', 'Restrooms', 'Parking', 'Wheelchair Access'],
    coordinates: { lat: 28.6562, lng: 77.2410 },
    yearBuilt: '1639-1648',
    builtBy: 'Emperor Shah Jahan',
    architecturalStyle: 'Mughal Architecture',
    unescoSite: true
  },
  {
    id: 'golden-temple',
    name: 'Golden Temple',
    location: 'Amritsar',
    state: 'Punjab',
    category: 'Temple',
    image: '/monuments/golden-temple.jpg',
    shortDescription: 'The holiest Gurdwara and most important pilgrimage site of Sikhism.',
    fullDescription: 'Harmandir Sahib, also known as the Golden Temple, is a Gurdwara located in Amritsar. It is the holiest shrine of Sikhism. The temple is built on a 67-foot square of marble and is a two-storied structure.',
    history: 'The fourth Guru of Sikhs, Guru Ram Das, excavated a tank in 1577 and the town of Amritsar was built around it. The fifth Guru, Guru Arjan Dev, completed the construction of the temple in 1604 and installed the Adi Granth here.',
    visitingHours: 'Open 24 hours, 7 days a week',
    ticketFees: {
      indian: 'Free Entry',
      foreign: 'Free Entry'
    },
    bestTimeToVisit: 'September to March',
    facilities: ['Free Langar (Community Kitchen)', 'Free Accommodation', 'Cloak Room', 'Wheelchair Access', 'Guided Tours', 'Washrooms'],
    coordinates: { lat: 31.6200, lng: 74.8765 },
    yearBuilt: '1577-1604',
    builtBy: 'Guru Ram Das & Guru Arjan Dev',
    architecturalStyle: 'Sikh Architecture',
    unescoSite: false
  },
  {
    id: 'hawa-mahal',
    name: 'Hawa Mahal',
    location: 'Jaipur',
    state: 'Rajasthan',
    category: 'Palace',
    image: '/monuments/hawa-mahal.jpg',
    shortDescription: 'The Palace of Winds with 953 small windows, an iconic landmark of Jaipur.',
    fullDescription: 'Hawa Mahal, or the Palace of Winds, is a palace in Jaipur built from red and pink sandstone. It was constructed so that women of the royal household could observe street life without being seen from outside.',
    history: 'Built in 1799 by Maharaja Sawai Pratap Singh, Hawa Mahal was designed by architect Lal Chand Ustad in the form of the crown of Krishna, the Hindu god. The palace is an extension of the Royal City Palace.',
    visitingHours: '9:00 AM to 5:00 PM (All days)',
    ticketFees: {
      indian: '₹50',
      foreign: '₹200'
    },
    bestTimeToVisit: 'November to February',
    facilities: ['Museum', 'Photography Allowed', 'Restrooms', 'Nearby Parking', 'Local Guides'],
    coordinates: { lat: 26.9239, lng: 75.8267 },
    yearBuilt: '1799',
    builtBy: 'Maharaja Sawai Pratap Singh',
    architecturalStyle: 'Rajput Architecture',
    unescoSite: false
  },
  {
    id: 'qutub-minar',
    name: 'Qutub Minar',
    location: 'Delhi',
    state: 'Delhi',
    category: 'Monument',
    image: '/monuments/qutub-minar.jpg',
    shortDescription: 'A soaring 73-meter tower of victory, the tallest brick minaret in the world.',
    fullDescription: 'Qutub Minar is a 73-meter tall minaret that forms part of the Qutub complex. The tower has five distinct storeys and is covered with intricate carvings and verses from the Quran.',
    history: 'Construction was started in 1193 by Qutub-ud-din Aibak and completed by his successor Iltutmish. The top storeys were rebuilt by Firoz Shah Tughlaq in 1368 after lightning damage. The minar is made of red sandstone and marble.',
    visitingHours: '7:00 AM to 5:00 PM (All days)',
    ticketFees: {
      indian: '₹35',
      foreign: '₹550'
    },
    bestTimeToVisit: 'October to March',
    facilities: ['Archaeological Museum', 'Guided Tours', 'Restrooms', 'Parking', 'Wheelchair Access', 'Garden'],
    coordinates: { lat: 28.5245, lng: 77.1855 },
    yearBuilt: '1193-1220',
    builtBy: 'Qutub-ud-din Aibak',
    architecturalStyle: 'Indo-Islamic Architecture',
    unescoSite: true
  },
  {
    id: 'mysore-palace',
    name: 'Mysore Palace',
    location: 'Mysore',
    state: 'Karnataka',
    category: 'Palace',
    image: '/monuments/mysore-palace.jpg',
    shortDescription: 'A grand royal residence and one of the most visited attractions in India.',
    fullDescription: 'Mysore Palace, also known as Amba Vilas Palace, is a historical palace and royal residence. It is one of the most famous tourist attractions in India with over 6 million annual visitors.',
    history: 'The original palace was built in the 14th century but was demolished and rebuilt several times. The current structure was built between 1897 and 1912 by British architect Henry Irwin for the 24th ruler of the Wodeyar dynasty.',
    visitingHours: '10:00 AM to 5:30 PM (All days)',
    ticketFees: {
      indian: '₹70',
      foreign: '₹200'
    },
    bestTimeToVisit: 'October to February (Visit during Dasara for special illumination)',
    facilities: ['Sound & Light Show', 'Museum', 'Royal Collection', 'Restrooms', 'Parking', 'Gift Shop'],
    coordinates: { lat: 12.3052, lng: 76.6552 },
    yearBuilt: '1897-1912',
    builtBy: 'Krishnaraja Wodeyar IV',
    architecturalStyle: 'Indo-Saracenic Architecture',
    unescoSite: false
  },
  {
    id: 'konark-sun-temple',
    name: 'Konark Sun Temple',
    location: 'Konark',
    state: 'Odisha',
    category: 'Temple',
    image: '/monuments/konark-sun-temple.jpg',
    shortDescription: 'A 13th-century temple shaped like a giant chariot with intricate carvings.',
    fullDescription: 'The Konark Sun Temple is a 13th-century Hindu temple dedicated to the sun god Surya. It is designed in the shape of a colossal chariot with twelve pairs of elaborately carved wheels pulled by seven horses.',
    history: 'Built by King Narasimhadeva I of the Eastern Ganga dynasty in 1250 CE, the temple was called the "Black Pagoda" by European sailors as it appeared dark and was used as a navigation landmark. It was built as a massive chariot of the Sun God.',
    visitingHours: '6:00 AM to 8:00 PM (All days)',
    ticketFees: {
      indian: '₹40',
      foreign: '₹600'
    },
    bestTimeToVisit: 'October to March (Visit during Konark Dance Festival in December)',
    facilities: ['Archaeological Museum', 'Guided Tours', 'Restrooms', 'Parking', 'Beach Nearby', 'Cultural Events'],
    coordinates: { lat: 19.8876, lng: 86.0945 },
    yearBuilt: '1250 CE',
    builtBy: 'King Narasimhadeva I',
    architecturalStyle: 'Kalinga Architecture',
    unescoSite: true
  },
  {
    id: 'gateway-of-india',
    name: 'Gateway of India',
    location: 'Mumbai',
    state: 'Maharashtra',
    category: 'Monument',
    image: '/monuments/gateway-of-india.jpg',
    shortDescription: 'An iconic arch monument built to commemorate the visit of King George V.',
    fullDescription: 'The Gateway of India is an arch monument built in the 20th century in Mumbai. It overlooks the Arabian Sea and is one of India\'s most unique landmarks. The structure is a triumphal arch made of basalt.',
    history: 'Built to commemorate the visit of King George V and Queen Mary to Mumbai in December 1911, the foundation stone was laid in 1911 and the structure was completed in 1924. It was the first thing British Viceroys and Governors saw when they arrived in India by boat.',
    visitingHours: 'Open 24 hours (Best visited early morning or evening)',
    ticketFees: {
      indian: 'Free Entry',
      foreign: 'Free Entry'
    },
    bestTimeToVisit: 'November to February',
    facilities: ['Boat Rides', 'Street Food', 'Photography', 'Nearby Hotels', 'Taj Mahal Palace Hotel Adjacent'],
    coordinates: { lat: 18.9220, lng: 72.8347 },
    yearBuilt: '1911-1924',
    builtBy: 'George Wittet (Architect)',
    architecturalStyle: 'Indo-Saracenic Architecture',
    unescoSite: false
  },
  {
    id: 'khajuraho',
    name: 'Khajuraho Temples',
    location: 'Khajuraho',
    state: 'Madhya Pradesh',
    category: 'Temple',
    image: '/monuments/khajuraho.jpg',
    shortDescription: 'A group of Hindu and Jain temples famous for their stunning sculptures.',
    fullDescription: 'The Khajuraho Group of Monuments is a group of Hindu and Jain temples famous for their nagara-style architectural symbolism and erotic sculptures. Most temples were built between 885 CE and 1050 CE by the Chandela dynasty.',
    history: 'Originally, there were 85 temples, of which only 25 survive today. The temples remained unknown until British engineer T.S. Burt rediscovered them in 1838. The sculptures depict various aspects of human life including spirituality, mythology, and eroticism.',
    visitingHours: 'Sunrise to Sunset (5:00 AM to 6:00 PM)',
    ticketFees: {
      indian: '₹40',
      foreign: '₹600'
    },
    bestTimeToVisit: 'October to February (Visit during Khajuraho Dance Festival)',
    facilities: ['Sound & Light Show', 'Archaeological Museum', 'Guided Tours', 'Restrooms', 'Parking', 'Cafeteria'],
    coordinates: { lat: 24.8318, lng: 79.9199 },
    yearBuilt: '885-1050 CE',
    builtBy: 'Chandela Dynasty',
    architecturalStyle: 'Nagara Architecture',
    unescoSite: true
  },
  {
    id: 'meenakshi-temple',
    name: 'Meenakshi Amman Temple',
    location: 'Madurai',
    state: 'Tamil Nadu',
    category: 'Temple',
    image: '/monuments/meenakshi-temple.jpg',
    shortDescription: 'A historic Hindu temple with stunning colorful gopurams (gateway towers).',
    fullDescription: 'The Meenakshi Amman Temple is a historic Hindu temple located in Madurai. It is dedicated to Goddess Meenakshi (Parvati) and Lord Sundareswarar (Shiva). The temple has 14 magnificent gopurams with thousands of colorful sculptures.',
    history: 'The original temple was built by Kulasekara Pandya but was destroyed. The present temple was rebuilt by the Nayak rulers in the 16th-17th century. The temple complex covers 14 acres and has over 33,000 sculptures.',
    visitingHours: '5:00 AM to 12:30 PM, 4:00 PM to 9:30 PM',
    ticketFees: {
      indian: '₹50 (Special Entry)',
      foreign: '₹50 (Special Entry)'
    },
    bestTimeToVisit: 'October to March (Visit during Chithirai Festival in April-May)',
    facilities: ['Temple Museum', 'Pooja Services', 'Restrooms', 'Cloak Room', 'Guided Tours', 'Prasad Counter'],
    coordinates: { lat: 9.9195, lng: 78.1193 },
    yearBuilt: '1623-1655 CE (rebuilt)',
    builtBy: 'Thirumalai Nayak',
    architecturalStyle: 'Dravidian Architecture',
    unescoSite: false
  }
]

export function getMonumentById(id: string): Monument | undefined {
  return monuments.find(m => m.id === id)
}

export function getMonumentsByCategory(category: Monument['category']): Monument[] {
  return monuments.filter(m => m.category === category)
}

export function searchMonuments(query: string): Monument[] {
  const lowercaseQuery = query.toLowerCase()
  return monuments.filter(m => 
    m.name.toLowerCase().includes(lowercaseQuery) ||
    m.location.toLowerCase().includes(lowercaseQuery) ||
    m.state.toLowerCase().includes(lowercaseQuery) ||
    m.category.toLowerCase().includes(lowercaseQuery)
  )
}

export function getRecommendedMonument(): Monument & { reason: string } {
  const currentMonth = new Date().getMonth() + 1 // 1-12
  
  // Seasonal recommendations
  if (currentMonth >= 10 || currentMonth <= 2) {
    // Winter: October to February - Best for most monuments
    const winterPicks = ['taj-mahal', 'khajuraho', 'konark-sun-temple', 'mysore-palace']
    const randomPick = winterPicks[Math.floor(Math.random() * winterPicks.length)]
    const monument = monuments.find(m => m.id === randomPick)!
    return {
      ...monument,
      reason: 'Perfect winter weather for exploring! The pleasant temperatures make it ideal for outdoor sightseeing.'
    }
  } else if (currentMonth >= 3 && currentMonth <= 5) {
    // Spring: March to May - Indoor or hill station monuments
    const springPicks = ['golden-temple', 'meenakshi-temple', 'mysore-palace']
    const randomPick = springPicks[Math.floor(Math.random() * springPicks.length)]
    const monument = monuments.find(m => m.id === randomPick)!
    return {
      ...monument,
      reason: 'Great time to visit before the monsoon! Early mornings are pleasant for sightseeing.'
    }
  } else {
    // Monsoon: June to September - Indoor attractions
    const monsoonPicks = ['mysore-palace', 'red-fort', 'hawa-mahal']
    const randomPick = monsoonPicks[Math.floor(Math.random() * monsoonPicks.length)]
    const monument = monuments.find(m => m.id === randomPick)!
    return {
      ...monument,
      reason: 'Monsoon special! These monuments are beautiful in the rainy season and offer good shelter.'
    }
  }
}
